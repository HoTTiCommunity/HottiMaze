package com.example.HottiMaze.controller;

import com.example.HottiMaze.dto.PostCreateDto;
import com.example.HottiMaze.dto.PostDto;
import com.example.HottiMaze.dto.PostUpdateDto;
import com.example.HottiMaze.entity.Category;
import com.example.HottiMaze.entity.Post;
import com.example.HottiMaze.service.PostService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/post")
@RequiredArgsConstructor
public class PostViewController {

    private final PostService postService;

    /**
     * 0) 루트 경로("/") 혹은 "/post"로 접속 시 자동으로 "/post/list"로 리다이렉트
     */
    @GetMapping(path = {"/", ""})
    public String redirectRoot() {
        // "/post" 또는 "/post/" 요청이 들어오면 "/post/list"로 리다이렉트
        return "redirect:/post/list";
    }

    /**
     * 1) 게시글 목록 페이지
     *    URL: GET /post/list
     *    뷰: post-list.html
     */
    @GetMapping("/list")
    public String boardList(Model model) {
        List<PostDto> allPosts = postService.getAllPosts();
        model.addAttribute("posts", allPosts);
        return "post-list";   // src/main/resources/templates/post-list.html
    }

    /**
     * 2) 게시글 상세(퀴즈 풀이 + 자유 그리기) 페이지
     *    URL: GET /post/{postId}
     *    뷰: post-detail.html
     */
    @GetMapping("/{postId}")
    public String postDetail(@PathVariable Long postId, Model model) {
        PostDto postDto = postService.getPostById(postId);
        model.addAttribute("post", postDto);
        return "post-detail";  // src/main/resources/templates/post-detail.html
    }

    /**
     * 3) 게시글 생성 폼
     *    URL: GET /post/create
     *    뷰: post-create.html
     */
    @GetMapping("/create")
    public String createPostForm(Model model) {
        List<Category> categories = postService.getAllCategories();
        model.addAttribute("categories", categories);
        model.addAttribute("postCreateDto", new PostCreateDto());
        return "post-create";  // src/main/resources/templates/post-create.html
    }

    /**
     * 4) 게시글 생성 처리
     *    URL: POST /post/create
     */
    @PostMapping("/create")
    public String createPost(@ModelAttribute PostCreateDto postCreateDto) {
        postService.createPost(postCreateDto);
        // 생성 후 목록 페이지로 리다이렉트
        return "redirect:/post/list";
    }

    /**
     * 5) 게시글 삭제
     *    URL: GET /post/delete/{postId}
     */
    @GetMapping("/delete/{postId}")
    public String deletePost(@PathVariable Long postId) {
        postService.deletePost(postId);
        return "redirect:/post/list";
    }

    /**
     * 6) 게시글 수정 폼
     *    URL: GET /post/edit/{postId}
     */
    @GetMapping("/edit/{postId}")
    public String editPost(@PathVariable Long postId, Model model) {
        // 기존 Post 엔티티에서 데이터 읽어와 DTO로 세팅
        Post postEntity = postService.getPostEntityById(postId);
        PostUpdateDto postUpdateDto = new PostUpdateDto();
        postUpdateDto.setTitle(postEntity.getTitle());
        postUpdateDto.setContent(postEntity.getContent());
        postUpdateDto.setCategoryId(postEntity.getCategory() != null
                ? postEntity.getCategory().getId() : null);

        // 카테고리 목록을 함께 넘김
        List<Category> categories = postService.getAllCategories();
        model.addAttribute("categories", categories);
        model.addAttribute("postUpdateDto", postUpdateDto);
        model.addAttribute("postId", postId);

        return "post-edit";   // src/main/resources/templates/post-edit.html
    }

    /**
     * 7) 게시글 수정 처리
     *    URL: POST /post/edit/{postId}
     */
    @PostMapping("/edit/{postId}")
    public String updatePost(@PathVariable Long postId,
                             @ModelAttribute PostUpdateDto postUpdateDto) {
        postService.updatePost(postId, postUpdateDto);
        // 수정 후 해당 게시글 상세로 리다이렉트
        return "redirect:/post/" + postId;
    }

    /**
     * 8) 북마크 전용 페이지
     *    URL: GET /post/bookmarks
     *    뷰: bookmarks.html
     *
     *    로컬스토리지 기반 필터링을 위해 전체 게시글 리스트 전달
     */
    @GetMapping("/bookmarks")
    public String bookmarkPage(Model model) {
        List<PostDto> allPosts = postService.getAllPosts();
        model.addAttribute("posts", allPosts);
        return "bookmarks";    // src/main/resources/templates/bookmarks.html
    }

    // ────────────────────────────────────────────────────────────────────
    // (필요하다면, 여기 아래에 다른 뷰 매핑 메서드를 추가하세요.)
    // 예: 검색 결과만 보여주는 전용 뷰가 필요하면 @GetMapping("/search") 등 추가 가능
    // ────────────────────────────────────────────────────────────────────
}

