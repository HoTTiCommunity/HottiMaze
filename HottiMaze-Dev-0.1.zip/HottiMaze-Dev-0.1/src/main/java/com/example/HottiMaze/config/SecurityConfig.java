package com.example.HottiMaze.config;

public class SecurityConfig {

}
