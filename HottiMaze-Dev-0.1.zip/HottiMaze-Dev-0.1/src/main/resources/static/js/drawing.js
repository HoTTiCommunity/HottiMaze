window.addEventListener('DOMContentLoaded', () => {
  const canvas = document.getElementById('drawing-canvas');
  const container = document.getElementById('detail-container');
  if (!canvas || !container) {
    return; // 상세 페이지가 아닐 경우 아무 동작 하지 않음
  }

  const ctx = canvas.getContext('2d');

  // 캔버스 크기를 컨테이너 크기에 맞추는 함수
  function resizeCanvas() {
    canvas.width = container.clientWidth;
    canvas.height = container.clientHeight;
  }
  window.addEventListener('load', resizeCanvas);
  window.addEventListener('resize', resizeCanvas);

  let drawing = false;
  let lastX = 0, lastY = 0;

  // 그리기 시작
  canvas.addEventListener('mousedown', (e) => {
    drawing = true;
    const rect = canvas.getBoundingClientRect();
    lastX = e.clientX - rect.left;
    lastY = e.clientY - rect.top;
  });

  // 그리기 중
  canvas.addEventListener('mousemove', (e) => {
    if (!drawing) return;
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    ctx.strokeStyle = 'red';
    ctx.lineWidth = 2;
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(lastX, lastY);
    ctx.lineTo(x, y);
    ctx.stroke();

    lastX = x;
    lastY = y;
  });

  // 그리기 종료
  canvas.addEventListener('mouseup', () => drawing = false);
  canvas.addEventListener('mouseout', () => drawing = false);

  // 캔버스 지우기
  window.clearCanvas = function() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
  };
});
