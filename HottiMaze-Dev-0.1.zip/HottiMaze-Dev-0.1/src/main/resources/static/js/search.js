window.addEventListener('DOMContentLoaded', () => {
  const searchInput = document.getElementById('search-input');
  const searchButton = document.getElementById('search-button');
  const postList = document.getElementById('post-list');
  const items = postList ? Array.from(postList.getElementsByTagName('li')) : [];

  function filterPosts() {
    const query = searchInput.value.trim().toLowerCase();
    items.forEach(li => {
      const title = li.getAttribute('data-title').toLowerCase();
      if (title.includes(query)) {
        li.classList.remove('hidden');
      } else {
        li.classList.add('hidden');
      }
    });
  }

  searchInput.addEventListener('keydown', e => {
    if (e.key === 'Enter') filterPosts();
  });
  searchButton.addEventListener('click', filterPosts);
});
