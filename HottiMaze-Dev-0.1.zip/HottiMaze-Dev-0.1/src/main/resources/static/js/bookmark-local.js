const STORAGE_KEY = 'hottimaze_bookmarks';

// localStorage에서 북마크 목록 읽기
function getBookmarks() {
  const raw = localStorage.getItem(STORAGE_KEY);
  return raw ? JSON.parse(raw) : [];
}

// 특정 ID가 북마크에 있는지 확인
function isBookmarked(id) {
  const arr = getBookmarks();
  return arr.includes(id);
}

// localStorage에 북마크 배열 저장
function setBookmarks(arr) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(arr));
}

// 아이콘 클릭 시 토글
function toggleBookmark(el) {
  const li = el.closest('li');
  const postId = li.getAttribute('data-id');
  let arr = getBookmarks();

  if (isBookmarked(postId)) {
    arr = arr.filter(x => x !== postId);
  } else {
    arr.push(postId);
  }
  setBookmarks(arr);
  updateIconState(el, postId);
}

// 아이콘 상태 업데이트 (★ 또는 ☆)
function updateIconState(el, postId) {
  if (isBookmarked(postId)) {
    el.textContent = '★';
    el.classList.add('bookmarked');
  } else {
    el.textContent = '☆';
    el.classList.remove('bookmarked');
  }
}

// 페이지 로드 시 초기 상태 세팅
window.addEventListener('DOMContentLoaded', () => {
  const icons = document.querySelectorAll('.bookmark-icon');
  icons.forEach(icon => {
    const li = icon.closest('li');
    const postId = li.getAttribute('data-id');
    updateIconState(icon, postId);
  });
});
