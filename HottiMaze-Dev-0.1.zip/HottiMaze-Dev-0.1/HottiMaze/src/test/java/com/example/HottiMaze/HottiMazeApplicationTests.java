package com.example.HottiMaze;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HottiMazeApplicationTests {

	@Test
	void contextLoads() {
	}

}
