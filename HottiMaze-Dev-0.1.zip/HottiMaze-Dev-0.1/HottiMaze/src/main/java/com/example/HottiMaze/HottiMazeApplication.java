package com.example.HottiMaze;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HottiMazeApplication {
	public static void main(String[] args) {
		SpringApplication.run(HottiMazeApplication.class, args);
	}
}
